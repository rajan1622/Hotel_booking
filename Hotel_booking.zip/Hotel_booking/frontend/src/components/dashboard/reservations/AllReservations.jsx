const AllReservations = () => {
  return (
    <div>
      <p>All reservations</p>
    </div>
  );
};

export default AllReservations;
