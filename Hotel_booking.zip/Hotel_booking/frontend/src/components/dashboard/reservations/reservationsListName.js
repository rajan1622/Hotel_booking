export const reservationListItems = [
    { name: "Upcoming", id: 1 },
    { name: "Completed", id: 2 },
    { name: "Canceled", id: 3 },
    { name: "All", id: 4 },
]