export const navItem = [
    { name: "Overview", id: 1, to: "/overview=true" },
    { name: "Reservations", id: 2, to: "/reservations" },
    { name: "Listing", id: 3, to: "/listing=true" },
    { name: "Create a new list", id: 4, to: "/become-a-host" },
];
